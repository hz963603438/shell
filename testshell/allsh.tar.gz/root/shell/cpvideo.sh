#!/bin/bash

nohup rsync -avr /root/shell/* /tmp/test &
