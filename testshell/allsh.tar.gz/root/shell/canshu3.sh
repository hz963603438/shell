#/bin/bash

echo $# 
echo $* 
echo $@
