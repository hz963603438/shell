#/bin/bash

echo "the current process is $$"

find / -name for1.sh &

echo "$!"
