#!/bin/bash

echo $#
echo $@
