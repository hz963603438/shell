#!/bin/bash

read -n2 -p "请输入两个字符: " any
echo -e "\n你输入的两个字符是:$any"
exit 0
