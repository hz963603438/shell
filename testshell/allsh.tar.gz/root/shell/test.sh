#!/bin/bash

ls /root/shell > ./test.txt
