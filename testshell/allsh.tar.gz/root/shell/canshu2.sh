#/bin/bash

num1=$1
num2=$2
sum=$(($num1 + $num2))
echo "sum is $sum"
