#!/bin/bash

cd /root/shell/testshell
tar -zcvf allsh.tar.gz  /root/shell/*.sh  
