#!/bin/bash


time=`date +%F`

df -h > $time.log
