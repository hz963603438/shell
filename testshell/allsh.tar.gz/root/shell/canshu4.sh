#/bin/bash

for i in "$*"
	do
		echo $i
	done

for y in "$@"
	do
		echo $y
	done
